export default{
    icDropDown: require('../assets/dropdown.png')
}